package BaseSetup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

public class Setup {

	public WebDriver driver;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(String browser, String url) {

		switch (browser) {
		case "chrome":
			driver = initChromeDriver(url);
			break;

		case "firefox":
			driver = initFirefoxDriver(url);
			break;

		default:
			System.out.println("browser : " + browser + " is invalid, Launching Firefox as browser of choice..");
			driver = initFirefoxDriver(url);
		}
	}

	private WebDriver initFirefoxDriver(String url) {
		WebDriver driver = new FirefoxDriver();
		//driver.manage().window().maximize();
		driver.get(url);
		return driver;
	}

	private WebDriver initChromeDriver(String url) {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Softwares\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		//driver.manage().window().maximize();
		driver.get(url);
		return driver;
	}

	@Parameters({"browser","url"})
	@BeforeClass

	public void initializeTestBaseSetup(String browser, String url) {
		try {
			setDriver(browser, url);

		} catch (Exception e) {
			System.out.println("Error....." + e.getStackTrace());
		}
	}

	/*@AfterClass
	public void tearDown() {
		driver.quit();
	}*/

}
