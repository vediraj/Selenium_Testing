package Tests;

import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseSetup.Setup;
import pageObjects.HomePage;
import pageObjects.LoginPage;

public class HomePageTest extends Setup {

	public WebDriver driver;

	@BeforeClass
	public void Setup() {
		driver = getDriver();
	}

	@Test
	public void testHomePage() {

		LoginPage login = new LoginPage(driver);
		HomePage home = new HomePage(driver);

		login.verifySignIn();
		String homemsg = home.getWelcomeMessage();
		AssertJUnit.assertEquals("Welcome Robert!!!", homemsg);
		
	}
	@AfterClass
	public void Close() {
		driver.close();;
	}

}
