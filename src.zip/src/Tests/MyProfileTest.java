package Tests;

import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseSetup.Setup;
import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.MyProfilePage;

public class MyProfileTest extends Setup {

	public WebDriver driver;
	
	@BeforeClass
	public void Setup() {
		driver = getDriver();
	}
	
	@Test
	public void testMyProfile(){
				
		LoginPage login = new LoginPage(driver);
		HomePage home = new HomePage(driver);
		MyProfilePage profile = new MyProfilePage(driver);
		
		login.verifySignIn();
		profile.clickProfile();
		Assert.assertEquals("Admin", profile.getUsername());
		Assert.assertTrue(profile.verifyMyProfile(), "Profile details are not correct"); 
		
	}
	@AfterClass
	public void Close() {
		driver.close();;
	}
	
}
