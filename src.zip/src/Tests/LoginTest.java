package Tests;

import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseSetup.Setup;
import pageObjects.LoginPage;

public class LoginTest extends Setup {

	public WebDriver driver;

	@BeforeClass
	public void Setup() {
		driver = getDriver();
	}

	@Test
	public void testLoginPage() {

		LoginPage login = new LoginPage(driver);
		
		Assert.assertTrue(login.verifySignIn(), "Login is Failed");

	}
	@AfterClass
	public void Close() {
		driver.close();;
	}
}
