package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.How;
//import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	public WebDriver driver;
	public By userName = By.name("username");
	public By password = By.name("password");
	public By loginBtn = By.name("login");

	public LoginPage(WebDriver driver) {
		// PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	// @FindBy(how=How.NAME,using="username")
	// public WebElement username;

	public void setUserName(String strUserName) {
		WebElement userNameElement = driver.findElement(userName);
		if (userNameElement.isDisplayed()) {
			userNameElement.sendKeys(strUserName);
		} else
			System.out.println("Element not found");
	}

	public void setPassword(String strPassword) {
		WebElement passwordElement = driver.findElement(password);
		if (passwordElement.isDisplayed()) {
			passwordElement.sendKeys(strPassword);
		} else
			System.out.println("Element not found");
	}

	public void clickLogin() {
		WebElement loginBtnElement = driver.findElement(loginBtn);
		if (loginBtnElement.isDisplayed()) {
			loginBtnElement.click();
		} else
			System.out.println("Element not found");
	}

	public boolean verifySignIn() {

		setUserName("Admin");
		setPassword("admin123");
		clickLogin();

		return true;

	}
}
