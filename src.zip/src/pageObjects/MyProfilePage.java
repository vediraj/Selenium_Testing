package pageObjects;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
import org.testng.Assert;

	public class MyProfilePage {

		WebDriver driver;
		private By name = By.xpath("/html/body/table/tbody/tr[1]/td[2]");
		private By username = By.xpath("/html/body/table/tbody/tr[2]/td[2]");
		private By email = By.xpath("/html/body/table/tbody/tr[3]/td[2]");
		private By role = By.xpath("/html/body/table/tbody/tr[4]/td[2]");
		private By address = By.xpath("/html/body/table/tbody/tr[5]/td[2]");
		private By city = By.xpath("/html/body/table/tbody/tr[6]/td[2]");
		private By state = By.xpath("/html/body/table/tbody/tr[7]/td[2]");
		private By profile = By.id("profile");
		
		public MyProfilePage(WebDriver driver){
			this.driver = driver;
		}
		
		public String getName(){
			return driver.findElement(name).getText();
		}
		
		public String getUsername(){
			return driver.findElement(username).getText();
		}
		
		public String getEmail(){
			return driver.findElement(email).getText();
		}
		
		public String getRole(){
			return driver.findElement(role).getText();
		}
		
		public String getAddress(){
			return driver.findElement(address).getText();
		}
		
		public String getCity(){
			return driver.findElement(city).getText();
		}
		
		public String getState(){
			return driver.findElement(state).getText();
		}
		
		public void clickProfile(){
			WebElement MyProfileElement = driver.findElement(profile);
			if (MyProfileElement.isDisplayed()) {
				MyProfileElement.click();
			} else
				System.out.println("Element not found");
		}
		
		public boolean verifyMyProfile(){
			
			getName();
			getUsername();
			getEmail();
			getRole();
			getAddress();
			getCity();
			getState();
			
			return true;
			
		}
	}



