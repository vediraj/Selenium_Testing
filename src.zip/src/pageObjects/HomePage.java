package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {

	public WebDriver driver;
	private By welcomeMsg = By.tagName("h2");

	public HomePage(WebDriver driver) {
		this.driver = driver;

	}

	public String getWelcomeMessage() {
		WebElement welcomeMsgElement = driver.findElement(welcomeMsg);
		String message = welcomeMsgElement.getText();

		return message;

	}
}
